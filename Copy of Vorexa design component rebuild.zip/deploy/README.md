# Vorexa — deploy folder

Static site. No build step, no dependencies.

## Deploy on Vercel (fastest)
1. Go to vercel.com/new
2. Drag this whole folder onto the page (or `npx vercel` from inside it)
3. Framework preset: **Other**. Build command: none. Output directory: `./`

## Files
- `index.html` — the site
- `support.js` — runtime it loads
- `image-slot.js` — image placeholder component
- `spiderman-tee.png` — product photo (10 MB — compress to JPG under 500 KB before going live)
- `vx-lockup-*.svg`, `watermark-mark.png` — logo and watermark

## Notes
- The contact form posts to Formspree (`mppzrnob`) and needs internet.
- Point a custom domain at the project in Vercel → Settings → Domains.
